function s_ssechant=echantillonnage(x,signal)

s_ssechant=signal(1:x:length(signal));

end
