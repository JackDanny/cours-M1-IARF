function [I2]=quantifw(I,n)

