function [Mcout,cout,Mchemin] = dtw_IAN(MRec,MRef) 

%MRec matrice du signal à reconnaitre
%MRef matrice du signal de reference


