s=wavread('musique-extrait.wav');


DEMO;
%qt=cqt(s,)