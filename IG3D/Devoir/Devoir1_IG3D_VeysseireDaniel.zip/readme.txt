Cette archive contient le devoir numero 1 d'IG3D.

Elle contient: 
    -Une archive avec les sources
    -Une archive contenant les rapports écrits à différents formats
    -le fichier readme ici présent


Pour tout problème, erreur, droit d'auteur, omission, suggestions,remarques, précisions
vous pouvez me contacter à cette adresse:

wedg@hotmail.fr

Merci et bonne journée,
Veysseire Daniel
