#include "gldrawable.h"
namespace rendersystem {

GlDrawable::GlDrawable()
{
}

}
