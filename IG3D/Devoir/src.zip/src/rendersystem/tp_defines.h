#ifndef TP_DEFINES_H
#define TP_DEFINES_H

//#define PATCH //maybe for asdsi TP1_G ?
//#define POINT_CLOUD
//#define BEZIER_C
//#define BSPLINE_C
//#define HERMIT_C
//#define BEZIER_P
//#define BSPLINE_P
//#define RAYTRACER

//#define ASDSI_TP1_R // meme chose que M2SIR_TP1
//#define ASDSI_TP2_R
//#define ASDSI_TP1_G
//#define ASDSI_TP2_G
#define IIG3D_TP1 // meme chose que M1_SIR_TP1_R
#define IIG3D_TP2
#define IIG3D_TP3
#define IIG3D_TP4
#define IIG3D_TP5
//#define SIR_TP6
//#define SIR_TP7
//#define SCENE_ANIM_HERMIT
//#define SCENE_ANIM_BEZIER
//#define SCENE_BEZIER_PATCH
//#define TEXTURE_FILTER
//#define M2SIR_TP1_R
//#define GREEDY_SAH


#endif // TP_DEFINES_H
